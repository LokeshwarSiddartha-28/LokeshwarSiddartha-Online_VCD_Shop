

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.DatabaseConnection;

/**
 * Servlet implementation class CreateStore
 */
@WebServlet("/CreateStore")
public class CreateStore extends HttpServlet {
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
		 String store = request.getParameter("store");
		  HttpSession hs = request.getSession();
		 try {
	        	
	            //Connecting database connection and querying in the database
	            int addCustomer = DatabaseConnection.insertUpdateFromSqlQuery("insert into store values('"+store+"')");

	            //If customer registered successfully
	            if (addCustomer > 0) {
	                String message = "Store created successfully.";
	                //Passing message via session.
	                hs.setAttribute("success-message", message);
	                //Sending response back to the user/customer
	                response.sendRedirect("create_store.jsp");
	            } else {
	                //If customer fails to register 
	                String message = "Store create fail";
	                //Passing message via session.
	                hs.setAttribute("fail-message", message);
	                //Sending response back to the user/customer
	                response.sendRedirect("create_store.jsp");
	            }
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	    }
}
