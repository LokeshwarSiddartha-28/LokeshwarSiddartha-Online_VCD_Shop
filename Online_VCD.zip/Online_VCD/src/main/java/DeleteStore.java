

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.connection.DatabaseConnection;

/**
 * Servlet implementation class DeleteStore
 */
@WebServlet("/DeleteStore")
public class DeleteStore extends HttpServlet {
	 protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
		 String store = request.getParameter("store");
		  HttpSession hs = request.getSession();
		 try {
	        	
	            //Connecting database connection and querying in the database
	            int addCustomer = DatabaseConnection.insertUpdateFromSqlQuery("delete from store where st='"+store+"'");

	            //If customer registered successfully
	           
	                String message = "Store deleted successfully.";
	                //Passing message via session.
	                hs.setAttribute("success-message", message);
	                //Sending response back to the user/customer
	                response.sendRedirect("delete_store.jsp");
	           
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	    }

}
