package zoho;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Z {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  Connection connection=null;
		
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinevcd","root","YJM@104");
		System.out.print("connected sucessfully");
		}catch(Exception e) {
			System.out.print("error occured");
		}
		String sql="INSERT INTO tbladmin(added_date,email,password,name) VALUES('admin@gmail.com','admin','Yajnesh');";
		try {
			PreparedStatement pre=connection.prepareStatement(sql);
			pre.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
	}

}
